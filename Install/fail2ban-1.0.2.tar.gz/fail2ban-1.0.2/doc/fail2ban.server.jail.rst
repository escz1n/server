fail2ban.server.jail module
===========================

.. automodule:: fail2ban.server.jail
    :members:
    :undoc-members:
    :show-inheritance:
