fail2ban.client.jailsreader module
==================================

.. automodule:: fail2ban.client.jailsreader
    :members:
    :undoc-members:
    :show-inheritance:
